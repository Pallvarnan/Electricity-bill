/**
 * 
 */
/**
 * @author sarat
 *
 */
module Electricity_bill {
}